/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exc4;

/**
 *
 * @author Admin
 */
public class Exc4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    int n =5;
        
    if (n%2>=0){
        System.out.println(n + "� um numero par");
    }else {
         System.out.println (n + "nao um numero impar");
        }
      
    }
}


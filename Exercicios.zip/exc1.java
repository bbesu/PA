/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg1;

public class exc1 {
    public static void main(String[] args) {
 
                         int num =10;
                        
                
              if(num%2==0) {  
                System.out.println(num + "� divisivel por 2.");
            }else {
                 System.out.println(num + " nao e divisivel por 2.");
    }
}
}
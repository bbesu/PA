/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exc5;

/**
 *
 * @author Admin
 */
public class Exc5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int idade =21;
                
                if(18<=idade || idade>=65) {
    System.out.println(idade + " esta dentro da variavel de idade de 18 a 65 anos");
        }else {
          System.out.println(idade + " esta fora da variavel de idade de 18 a 65 anos");
                }
    }
}
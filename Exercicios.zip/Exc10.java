/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exc10;

/**
 *
 * @author Admin
 */
public class Exc10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        int num=4;
        int num1=41;
   
    if(num1+num>50 || num+num1>50) {
        System.out.println(num+num1 + " é maior que 50");
    } else{
        System.out.println(num+num1 + " nao é maior que 50" );
            }
        
    }
    
}

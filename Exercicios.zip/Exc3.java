/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exc3;

/**
 *
 * @author Admin
 */
public class Exc3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    int num = 150;
    
    if(num>100){
        System.out.println(num + " � maior que 100");
    }
  }
}
